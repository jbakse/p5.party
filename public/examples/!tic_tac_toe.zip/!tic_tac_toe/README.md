# tic tac toe

This example shows a multiplayer tic-tac-toe game; users can choose a team and play in turn with others.

- **pick** a team from the select menu
- **click** to add a mark on your turn
- **clear** the board

> Open this example in two browser windows at once!
